# PantryPilot 🚀🍏

PantryPilot is an ultra-premium, AI-driven smart nutrition, grocery, and pantry management application built with Flutter. It seamlessly merges health goals, household inventory, and financial analytics into a singular, breathtaking minimalist user experience.

## 🛠 Tech Stack
* **Frontend**: Flutter (Dart)
* **State Management**: Riverpod (`ConsumerWidget`, `StateNotifier`)
* **Local Storage**: Hive (Fast, NoSQL local database)
* **AI Integration**: Google Generative AI (Gemini 2.5 Flash)
* **Backend Utilities**: Node.js (Allergens & Usage limits)

## ✨ Main Features
* **Multimodal Diet Scanner**: Import diets directly from a photo or a PDF with Gemini 2.5 Flash for OCR, translation, and portion sizing.
* **Smart Price Estimation**: Estimates the precise cost of any generated grocery list in multiple countries (IT, DE, CH).
* **Zero-Waste Recipe Generator ("Svuota Frigo")**: Analyzes expiring pantry items to generate intelligent recipes that minimize food waste.
* **Unified Analytics Dashboard**: A dual-tab powerhouse tracking both physical health (macronutrients) and financial spending.
* **Magic Pantry & Unified Food System**: Automatically deducts recipe ingredients from the virtual Pantry inventory and intelligently merges duplicate foods.
* **Premium Aesthetic & UI**: Minimalist design with zero emojis, glassmorphic navigation, and immersive cooking mode.
* **[NEW] Diet Reuse & Calendar Integration**: Intelligently reuse and plan your previous diets over time through a seamless calendar interface.
* **[NEW] Smart Allergens Backend**: New backend capabilities to handle and filter allergens across your meals and inventory.

## 📸 Gallery
### Dashboard & UI
![Dashboard Overview](screenshots/dashboard.png)

### Diet Calendar & Reuse
![Diet Calendar](screenshots/diet_calendar.png)

### Analytics
![Analytics](screenshots/analytics.png)

---
*Demo live: [Link to Live Demo (Coming Soon)](#)*
