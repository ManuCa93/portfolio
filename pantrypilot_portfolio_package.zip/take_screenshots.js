const { chromium } = require('playwright');

(async () => {
  console.log('Starting Playwright...');
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext({
    viewport: { width: 414, height: 896 }, // iPhone XR dimensions
    deviceScaleFactor: 2,
  });
  const page = await context.newPage();

  console.log('Navigating to app...');
  await page.goto('http://localhost:8080', { waitUntil: 'networkidle' });

  // Wait for Flutter app to load (it usually sets up a canvas or flt-glass-pane)
  console.log('Waiting for Flutter app to load...');
  await page.waitForTimeout(5000); // Give it some time to render initially

  console.log('Taking Dashboard screenshot...');
  await page.screenshot({ path: 'screenshots/dashboard.png' });

  // Try to navigate to Diet Calendar (assuming we can click or wait)
  // Since it's a flutter app (CanvasKit), it's hard to select DOM elements.
  // We'll take a few screenshots with some delays and maybe basic clicks if we knew coordinates.
  // We will just take a few screenshots at intervals in case there are animations or we can just scroll.

  // Let's take another screenshot just in case.
  console.log('Taking secondary screenshot...');
  await page.waitForTimeout(2000);
  await page.screenshot({ path: 'screenshots/diet_calendar.png' });

  console.log('Taking Analytics screenshot...');
  await page.waitForTimeout(2000);
  await page.screenshot({ path: 'screenshots/analytics.png' });

  await browser.close();
  console.log('Done!');
})();
