# 🏁 MotoGP Position Estimator

Machine learning suite that predicts live lap times, grid positions, race pace and tyre strategy for MotoGP, acting as a "Virtual Pit Wall". Built on a SQLite pipeline ingesting real PDF timing sheets (2024–2026 seasons, 34 riders, 23 circuits, ~73k laps).

![Live Session Replay - Time Attack mode](screenshots/dashboard_time_attack.png)

## Highlights

- **Live Lap Time & Position Predictor** — estimates a rider's final lap time and live leaderboard position at each sector checkpoint (S1/S2/S3), using 5 parallel regressors (XGBoost, SVR, Neural Network, Ridge, AdaBoost) combined into an ensemble + stacking model. Separate models for qualifying-style flying laps vs race-style laps.
- **Race Pace & Tyre Strategy Engine** — predicts a rider's average race pace, tyre degradation slope, and likely front/rear compound choice from Free Practice telemetry, recent form and weather conditions.
- **Race Weekend Analysis** *(new)* — a dedicated deep-dive per race weekend: report card grading FP/Quali/Sprint/Race, an **ideal lap** score (how close a rider's best lap came to the sum of their own best sectors — rewards clean execution independent of raw pace), lap-by-lap position/pace charts, and pace comparison across custom lap ranges.
- **Analytics Dashboard** — algorithmic rider ratings ("Le Pagelle"), rider profile with momentum indicator, circuit breakdown, head-to-head comparison, team/manufacturer performance trends, wet-weather masters, consistency index.
- **Advanced EDA** — 3D environmental mapping (temp/humidity/track condition vs tyre drop), Random Forest feature importance, K-Means/PCA circuit clustering, correlation analysis.

## Tech stack

Python · Flask · scikit-learn · XGBoost · pandas · SQLite · Chart.js · Plotly

## Screenshots

**Pre-race AI pace prediction**
![Pre-Race AI Pace Predictor](screenshots/dashboard_race_pace.png)

**Race Weekend Analysis — overview & report card**
![Race Weekend Analysis overview](screenshots/race_weekend_analysis_overview.png)

**Race Weekend Analysis — lap-by-lap position & pace**
![Race Weekend Analysis charts](screenshots/race_weekend_analysis_charts.png)

**Advanced Analytics — algorithmic rider grades**
![Advanced Analytics - Rider Grades table](screenshots/analytics_overview.png)

**Rider profile & circuit breakdown**
![Rider profile modal](screenshots/rider_profile_modal.png)
![Circuit Breakdown modal](screenshots/circuit_breakdown.png)

**Team & constructor performance**
![Team Performance - pace and season trend charts](screenshots/team_performance_charts.png)

**Environmental data exploration**
![EDA report - 3D environmental mapping](screenshots/eda_report.png)

---

🔗 **[Live demo](#)** — replace `#` with your Render URL
🔒 Source code private — screenshots and description only
