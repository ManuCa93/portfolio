# Polify

Un test politico che ti spiega ogni domanda prima di porla, calcolando quanto sei vicino a ciascun partito italiano (e internazionale) basandosi su 68 temi reali e documentati.

## Stack Tecnologico
Next.js 16 (App Router), React 19, Tailwind CSS v4, shadcn/ui, GSAP (animazioni 3D delle monete), Playwright (ispezione visiva e screenshot automatizzati).

## Funzionalità Principali
- **Motore di calcolo trasparente e documentato:** Confronta le risposte con posizioni di partito (239+ posizioni verificate e bloccate), pesate in base all'affidabilità delle fonti (es. voto parlamentare vs. dichiarazione).
- **Match Internazionale [NUOVA]:** Al termine del test, scopri le tue ideologie affini e i corrispettivi partiti in 10 nazioni diverse!
- **Analisi Area per Area:** Genera classifiche separate per 9 aree tematiche diverse (economia, diritti, ecc.), riconoscendo che nessuno è d'accordo su tutto con un unico partito.
- **Architettura a Redazione Separata:** Editor testuale locale (su porta dedicata) che permette ai redattori di creare e valutare le domande in tempo reale osservandone l'impatto sul modello matematico, senza toccare codice.
- **Risultati e Condivisione Privacy-First:** Confronto crittografato tramite URL ("Sfida"). Il server non salva nulla: tutti i calcoli avvengono nel browser e ogni profilazione sensibile è tutelata secondo le norme GDPR, restando esclusivamente sul dispositivo.
- **Estetica e UX Premium:** Interfaccia moderna e interattiva in bianco e nero (supporto nativo dark mode), micro-animazioni fluide, focus sulla leggibilità e design a singola colonna per massimizzare la concentrazione sulla domanda corrente. Contiene un glossario integrato per i termini complessi.

## Galleria

![Home Page con Animazione delle Monete](screenshots/home-desktop-scuro.png)
*La home page animata in tema scuro, con ritratti a inchiostro creati appositamente.*

![La Schermata del Sondaggio](screenshots/sondaggio-01-scala-con-spiegazione.png)
*Spiegazione trasparente e glossario a comparsa prima di prendere una decisione.*

![Risultati - Match Nazionale e Internazionale](screenshots/risultati-breve.png)
*I risultati con il gruppo di testa (tiene conto del margine di errore statistico) e il nuovo matching internazionale.*

![Classifiche Area per Area](screenshots/risultati-mobile.png)
*Dettaglio su scala mobile per capire l'affinità sulle singole tematiche (economia, diritti civili, etc.).*

![Modalità Sfida e Condivisione](screenshots/sfida-confronto.png)
*La modalità Sfida: condividi il tuo link univoco e scopri punti di contatto e divergenza con i tuoi amici.*

## Demo Live
[🌍 Vai alla Demo di Polify (Placeholder)](#)
