# Enjoy the Night — Portfolio Screenshots

**App:** Enjoy the Night (a.k.a. SoberTrack) — a Flutter (iOS/Android/Web) app that estimates
Blood Alcohol Content (BAC) in real time from logged drinks, and helps users plan a safe way
home.

All screenshots below were captured from a real running build of the app (Flutter Web, English
locale) using **mock/demo data** seeded specifically for this portfolio — no real user data is
involved. The mock profile is a 29-year-old, 78 kg / 178 cm male with a legal driving limit of
0.5 g/l, and a drink log spanning the last few hours plus several previous days, chosen to
exercise the app's ranges, limits and navigation controls.

Recommended display order and what each image demonstrates:

---

### 01 — Onboarding: Welcome (`01_onboarding_welcome.png`)
First-run screen. Introduces the safety disclaimer, gender selector, and the physical-profile
sliders (weight/height/age) at their default values (70 kg / 170 cm / 25 years).
**Shows:** initial empty state, segmented gender control, disclaimer widget.

### 02 — Onboarding: Profile Setup (`02_onboarding_profile_setup.png`)
Same screen after using the **+ / − stepper buttons** to move each slider to a new value
(78 kg / 178 cm / 29 years), demonstrating the min/max-bounded range controls a user tunes
before the app can calculate BAC accurately.
**Shows:** range controls (sliders with stepper buttons and hard min/max limits), live label
updates ("Weight: 78 kg").

### 03 — Dashboard Overview (`03_dashboard_overview.png`)
Main/home screen with 3 drinks logged earlier that evening. The circular BAC gauge is green
(under the legal limit), with a live countdown to sobriety ("Sober at 17:57") and a "today's
drinks" list (last 24h) with per-drink icons, volume/ABV and timestamps.
**Shows:** primary dashboard UI, animated BAC gauge, time-based countdown, list of logged
items.

### 04 — Add Drink Bottom Sheet (`04_add_drink_bottom_sheet.png`)
The modal opened from the orange "+" button, mid-interaction: "Shot" category selected and the
glass counter increased to 2 via its +/- stepper (showing the resulting volume/ABV recompute
live: 80 ml • 40% ABV). Also shows the stomach-status segmented control and the favorite
(heart) toggle.
**Shows:** modal bottom sheet UI, category chips, a bounded stepper control (1–20 glasses),
segmented buttons.

### 05 — Dashboard: Over-the-Limit Warning (`05_dashboard_over_limit_warning.png`)
Immediately after confirming the drink from screen 04. The BAC gauge turns orange, a red
"You are over the driving limit!" banner appears, and the hydration-recommendation card updates
its suggested water amount — all recalculated live from the same legal-limit threshold used
throughout the app.
**Shows:** threshold/limit-driven UI state changes, before → after interaction result.

### 06 — History: 24h BAC Trend (`06_history_chart_24h.png`)
The second tab (reached via the bottom navigation pill). Line chart of BAC over the last 24
hours, with a dashed red "Limit" line at the legal threshold and a dashed green projection to
the moment BAC returns to 0. Below the chart, the full drink history list for the period.
**Shows:** bottom tab navigation, time-series chart with a fixed limit line and a computed
future projection.

### 07 — History: 3h Quick Range (`07_history_chart_3h_range.png`)
Same History screen after tapping the "3h" quick-range chip (one of the 3h / 12h / 24h
presets) — the chart rescales to zoom into the most recent window.
**Shows:** quick range-switching navigation (preset chips acting as forward/backward time
window controls).

### 08 — Custom Date Range Picker (`08_custom_date_range_picker.png`)
The calendar dialog opened from the "Dates" chip, for selecting an arbitrary multi-day range
instead of a fixed preset. Dates after "today" are greyed out and cannot be selected, enforcing
the app's date range limit.
**Shows:** calendar-based navigation control, min/max selectable-date limits, multi-day range
selection.

### 09 — Settings Screen (`09_settings_screen.png`)
Profile and preference editor, reachable from the gear icon on the dashboard. Lets the user
revise gender, app theme (System/Light/Dark), weight/height/age (same bounded sliders as
onboarding), the "New Driver" toggle (which drops the legal limit to 0.0 g/l), and 24-hour vs
12-hour time format.
**Shows:** settings/preferences UI, segmented theme switch, bounded sliders, toggle switches.

---

## Suggested portfolio narrative

`01 → 02 → 03 → 04 → 05 → 06 → 07 → 08 → 09`

This order follows a natural user journey: first-run setup → tuning your profile → the daily
dashboard → logging a drink → seeing the safety warning it triggers → reviewing your BAC
history at different time scales → picking a custom date range → adjusting settings. Together
the set demonstrates the app's core navigation patterns (bottom tabs, quick-range chips, a
calendar picker), its range/limit-based logic (legal BAC limit, min/max sliders, date limits),
and its key interactive UI elements (bottom sheet, chips, steppers, segmented controls,
switches).
