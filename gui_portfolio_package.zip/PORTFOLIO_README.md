# Clinical Dashboard for Autism Screening Research

An offline clinical dashboard that lets a psychologist review a toddler's ADOS-2 assessment session — video, IMU toy sensors, and behavioral annotations — side by side, synchronized to the same timeline, plus a sensor-only screening view that shows what the raw motion data says on its own, without any manual annotation.

## Tech stack

Python - Dash / Plotly - Dash Bootstrap Components - dash-ag-grid - Flask (local static/video serving) - Pandas - Quill.js (rich-text notes editor, vendored, no CDN) - ReportLab / python-docx (report export) - scikit-learn model artifacts (read-only, for the sensor-only risk score)

Runs entirely on `localhost`, no outbound network calls — built for handling sensitive health data of minors under GDPR Art. 9.

## Key features

- **Dashboard Overview** — cohort-wide KPIs, ADOS score distribution by risk band, gender breakdown, toy-usage heatmap and label statistics, plus a filterable, paginated patient table with GDPR/AI-use disclosures in four languages.
- **Patient Detail** — video playback synchronized bidirectionally with an interactive label timeline and the raw IMU signal plot (click the timeline to seek the video; play the video to scrub the plot); toy and video angle are selected independently since one session can have multiple cameras and multiple sensorized toys.
- ***New* — Sensor-Only Analysis** — a screening view that runs the sensor-only ADOS risk model on a child's IMU data alone and reports it against the cohort's out-of-fold evidence (not a bare probability), a side-by-side comparison of session length / play time / movement bouts against the cohort and against same-risk peers, and three overlaid movement timelines (sensors alone, sensors vs. manual annotation, sensors minus educator-involved stretches) so a clinician can see exactly where automated detection agrees or disagrees with the human record.
- ***New* — data-quality transparency built into the same view** — sessions with a saturated sensor, a broken recording, or low sample coverage surface an explicit orange warning next to the prediction, instead of a silently wrong number.
- ***New* — Clinician Notes with AI Summary** — a full rich-text editor (Quill) supporting multiple notes per patient and multiple clinicians per note, each exportable to `.docx`/`.pdf`/`.txt`. Notes are summarized *extractively* (sentences lifted verbatim, never generated) after a documented test showed the generative alternative fabricating clinical claims about the child — the dashboard states this design choice on screen, not just in the docs.
- **Toy Analytics** — research-oriented cross-patient view: action counts, intentionality (child-initiated / accidental / educator-led) and action diversity (Shannon entropy) per toy, plus session-completeness tracking.

## Cohort data quality, at a glance

The dashboard surfaces per-child data completeness directly rather than hiding it behind an aggregate number:

- Most of the 24-child cohort have the full stack — video, IMU sensor files, standardized behavioral labels and an ADOS score — and get the complete view shown above.
- Seven recently onboarded children have sensor data and an ADOS score, but their manual behavioral labels are still marked **"Not yet"**; the patient card and the Consent/Labels column flag this rather than silently treating them as fully annotated.
- A couple of children have no usable session data at all, and one child's labels are currently unreadable (values only available in Spanish, not yet mapped) — again surfaced, not swallowed.
- Session-level sensor issues (a stuck/saturated toy sensor, a recording broken by a long gap) show up as an in-context warning on that child's Sensor-Only Analysis card.

## Screenshots

### Dashboard Overview
![Dashboard Overview](screenshots/01_dashboard_overview.png)
![Label statistics and toy usage heatmap](screenshots/02_dashboard_label_toy_stats.png)

### Patient Detail — complete data
![Patient card, complete data](screenshots/03_patient_card_complete_data.png)

### Sensor-Only Analysis (new)
![Sensor-only ADOS risk prediction and movement timelines](screenshots/04_sensor_only_analysis.png)

### Patient Detail — flagged / incomplete data
![Patient card, labels pending](screenshots/05_patient_card_pending_labels.png)
![Sensor-only analysis with data-quality warning](screenshots/06_sensor_only_analysis_data_quality_flags.png)

### Clinician Notes editor
![Clinician notes editor with AI summary panel](screenshots/07_clinician_notes_editor.png)

### Toy Analytics
![Most used toys leaderboard](screenshots/08_toy_analytics_leaderboard.png)
![Action diversity and intentionality per toy](screenshots/09_toy_analytics_entropy_intentionality.png)

---

**Live demo:** _[link placeholder — add live demo URL here]_
