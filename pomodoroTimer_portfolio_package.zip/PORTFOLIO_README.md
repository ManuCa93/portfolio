# Pomodoro Timer & Study Analytics

A modern, highly customizable Pomodoro timer available as both a desktop application (Electron) and a static web app. It’s designed to go beyond simple countdowns, acting as a lightweight task tracker and study analytics dashboard.

## 🛠 Tech Stack
- **Frontend**: Vanilla HTML, CSS, JavaScript (No frameworks)
- **Desktop Wrapper**: Electron
- **Data Visualization**: Chart.js
- **Storage**: Local Storage

## ✨ Key Features
- **Core Timer**: Classic Pomodoro flow (work → short break → long break) with a responsive circular progress indicator that scales perfectly on all screen sizes.
- **[NEW] Mini-Timer Widget**: A floating, always-on-top window (desktop) or popup (web) that keeps you aware of time even when working in other applications.
- **[NEW] Notion-Style Task Board**: Set a Macro-Subject, outline specific topics, and manage tasks in an interactive, keyboard-navigable table. Data is saved automatically.
- **[NEW] Info & Settings Panel**: A comprehensive settings area to adjust durations, fully customize the color theme (primary, background, breaks), and toggle aesthetic background bubbles.
- **Analytics Dashboard**: Keep track of your daily, weekly, monthly, and lifetime progress, visualized seamlessly with interactive charts.

## 📸 Gallery
*(Select a view to see the interface)*

![Main Timer View](screenshots/main_timer.png)
![Tasks Panel](screenshots/tasks_panel.png)
![Info Settings](screenshots/info_settings.png)
![Mini Timer](screenshots/mini_timer.png)

## 🔗 Links
- [Live Demo](#) <!-- Replace with live URL -->
- [GitHub Repository](#) <!-- Replace with repo URL -->
